import './button.scss';
const Button = () => {

    return (
        <button className="button">
            <span> + </span>
            <span> New Message </span>
        </button>
    )
}
export default Button;