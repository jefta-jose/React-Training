import './inbox.scss'



const Inbox = () => {
    return (
        <div className='inbox'>
            <h2>inbox</h2>
        </div>
    )
}

export default Inbox