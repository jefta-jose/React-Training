import './sentmail.scss'

const SentMail = () => {
    return (
        <div className='mail'>
            <h2>sent mail</h2>
        </div>
    )
}

export default SentMail