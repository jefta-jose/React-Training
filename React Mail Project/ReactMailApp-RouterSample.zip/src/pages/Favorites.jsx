import './favorites.scss'

function Favorites() {
    return (
        <div>Favorites</div>
    )
}

export default Favorites