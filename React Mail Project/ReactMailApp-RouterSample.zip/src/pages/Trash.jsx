import React from 'react'

const Trash = () => {
    return (
        <div>Trash</div>
    )
}

export default Trash