import Main from "./layout/Main"
import './app.scss'
import { Routes, Route } from "react-router-dom";
import Login from "./pages/Login";
import Inbox from './pages/Inbox';
import Favorites from './pages/Favorites';
import Drafts from './pages/Drafts';
import Spam from './pages/Spam';
import Trash from './pages/Trash';
import SentMail from './pages/SentMail';


function App() {
  return (
    <>


    </>

  )
}

export default App
